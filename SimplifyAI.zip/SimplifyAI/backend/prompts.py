AGE_PROMPTS = {
    "child": """
Explain the topic to a child between 5 and 10 years old.

Rules:
- Use very simple vocabulary.
- Use short sentences.
- Use an everyday-life analogy.
- Avoid difficult technical words.
- Make the explanation friendly and easy to understand.
""",

    "teen": """
Explain the topic to a teenager between 11 and 16 years old.

Rules:
- Use simple but moderately technical vocabulary.
- Explain important technical terms.
- Use a practical example or analogy.
- Keep the explanation clear and structured.
""",

    "adult": """
Explain the topic to an adult aged 17 or above.

Rules:
- Provide a detailed explanation.
- Technical terminology can be used when appropriate.
- Explain important concepts clearly.
- Include relevant examples and details.
"""
}


def create_prompt(topic, age_group):
    instructions = AGE_PROMPTS.get(age_group)

    if instructions is None:
        return None

    prompt = f"""
Topic: {topic}

{instructions}
"""

    return prompt