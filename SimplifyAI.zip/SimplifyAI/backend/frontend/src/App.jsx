import { useRef, useState } from "react";
import {
  AlertCircle,
  ArrowRight,
  Atom,
  Baby,
  BookOpen,
  Brain,
  Check,
  Copy,
  GraduationCap,
  Lightbulb,
  LoaderCircle,
  Menu,
  Network,
  Sparkles,
  X,
} from "lucide-react";

const ageGroups = [
  { id: "child", label: "Child", detail: "Ages 5–10", Icon: Baby },
  { id: "teen", label: "Teen", detail: "Ages 11–16", Icon: GraduationCap },
  { id: "adult", label: "Adult", detail: "Ages 17+", Icon: BookOpen },
];

const examples = ["Artificial Intelligence", "Black Holes", "Blockchain", "Internet of Things"];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  function closeMenu() {
    setMenuOpen(false);
  }

  return (
    <header className="site-header">
      <div className="header-inner page-width">
        <a className="brand" href="#home" aria-label="SimplifyAI home" onClick={closeMenu}>
          <span className="brand-mark"><Lightbulb size={19} strokeWidth={2.2} /></span>
          <span className="brand-copy">
            <span className="brand-name">SimplifyAI</span>
            <span className="brand-tagline">Understand Anything</span>
          </span>
        </a>

        <nav className={`main-nav${menuOpen ? " is-open" : ""}`} aria-label="Main navigation">
          <a href="#home" onClick={closeMenu}>Home</a>
          <a href="#how-it-works" onClick={closeMenu}>How it works</a>
          <a href="#about" onClick={closeMenu}>About</a>
        </nav>

        <div className="header-actions">
          <span className="powered-badge"><span className="status-dot" /> AI powered</span>
          <button
            className="icon-button menu-toggle"
            type="button"
            aria-label={menuOpen ? "Close navigation" : "Open navigation"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>
    </header>
  );
}

function IdeaIllustration() {
  return (
    <div className="idea-illustration" aria-hidden="true">
      <div className="orbit orbit-outer" />
      <div className="orbit orbit-inner" />
      <div className="idea-core"><Brain size={42} strokeWidth={1.55} /></div>
      <div className="idea-node node-atom"><Atom size={22} /></div>
      <div className="idea-node node-network"><Network size={21} /></div>
      <div className="idea-node node-book"><BookOpen size={20} /></div>
      <span className="spark spark-one"><Sparkles size={17} /></span>
      <span className="spark spark-two"><Sparkles size={12} /></span>
      <span className="illustration-caption">Curiosity, connected.</span>
    </div>
  );
}

function ExplanationPanel({ result, loading, error, onCopy, copied, onReset }) {
  if (!loading && !error && !result) return null;

  return (
    <section className="response-panel" aria-live="polite" aria-busy={loading}>
      {loading && (
        <div className="loading-state">
          <span className="loading-icon"><LoaderCircle size={22} /></span>
          <div>
            <h2>Making it make sense</h2>
            <p>Finding the clearest way to explain this idea...</p>
          </div>
          <div className="loading-bars" aria-hidden="true"><i /><i /><i /></div>
        </div>
      )}

      {error && (
        <div className="error-state" role="alert">
          <span className="error-icon"><AlertCircle size={20} /></span>
          <div className="error-copy">
            <h2>We couldn’t simplify that just yet</h2>
            <p>{error}</p>
          </div>
          <button className="text-button" type="button" onClick={onReset}>Try again</button>
        </div>
      )}

      {result && (
        <article className="result-content">
          <div className="result-topline">
            <div className="result-label"><span className="result-spark"><Sparkles size={14} /></span> Your simplified explanation</div>
            <span className={`result-age age-${result.age_group}`}>
              {ageGroups.find((group) => group.id === result.age_group)?.label ?? result.age_group}
              <span> · </span>
              {ageGroups.find((group) => group.id === result.age_group)?.detail}
            </span>
          </div>
          <h2 className="result-title">{result.topic}</h2>
          <div className="explanation-text">{result.explanation}</div>
          <div className="result-footer">
            <span className="result-note"><span className="status-dot" /> Made for your learning level</span>
            <button className="copy-button" type="button" onClick={onCopy}>
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? "Copied" : "Copy explanation"}
            </button>
          </div>
        </article>
      )}
    </section>
  );
}

function App() {
  const [topic, setTopic] = useState("");
  const [ageGroup, setAgeGroup] = useState("teen");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const inputRef = useRef(null);

  async function handleSubmit(event) {
    event.preventDefault();
    const cleanTopic = topic.trim();
    if (!cleanTopic || loading) return;

    setLoading(true);
    setError("");
    setResult(null);
    setCopied(false);

    try {
      const apiBase = import.meta.env.VITE_API_BASE_URL || "/api";
      const response = await fetch(`${apiBase.replace(/\/$/, "")}/explain`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: cleanTopic, age_group: ageGroup }),
      });

      const responseText = await response.text();
      let data = null;
      try {
        data = responseText ? JSON.parse(responseText) : null;
      } catch {
        data = null;
      }

      if (!response.ok) {
        const detail = data?.detail ?? data?.error;
        const detailMessage = Array.isArray(detail)
          ? detail.map((issue) => issue?.msg).filter(Boolean).join(" ")
          : typeof detail === "string"
            ? detail
            : "";
        const fallbackMessage = response.status >= 500
          ? "The AI service is having trouble right now. Please try again shortly."
          : `The request could not be completed (HTTP ${response.status}). Please check the topic and try again.`;
        throw new Error(detailMessage || fallbackMessage);
      }

      if (data?.error) {
        throw new Error(data.error);
      }
      if (!data || typeof data.explanation !== "string" || !data.explanation.trim()) {
        throw new Error("We received an empty explanation. Please try again.");
      }

      setResult(data);
    } catch (requestError) {
      setError(
        requestError instanceof TypeError
          ? "We couldn’t reach the explanation service. Check that the backend is running, then try again."
          : requestError.message || "Something went wrong. Please try again in a moment.",
      );
    } finally {
      setLoading(false);
    }
  }

  async function handleCopy() {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.explanation);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setError("Your browser couldn’t copy the text. You can still select and copy it manually.");
    }
  }

  function resetResult() {
    setError("");
    setResult(null);
    inputRef.current?.focus();
  }

  return (
    <div className="app-shell" id="home">
      <Header />

      <main>
        <section className="hero page-width">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> Your personal AI explainer</div>
            <h1>Big ideas.<br /><span>Made simple.</span></h1>
            <p className="hero-description">
              Turn complicated concepts into clear, simple explanations tailored to the way you learn.
            </p>
            <a className="hero-link" href="#simplifier">Explore a topic <ArrowRight size={16} /></a>
          </div>
          <IdeaIllustration />
        </section>

        <section className="workspace-section page-width" id="simplifier" aria-labelledby="form-title">
          <div className="workspace-heading">
            <div>
              <span className="section-kicker">Start with a question</span>
              <h2 id="form-title">What would you like to understand?</h2>
            </div>
            <span className="workspace-step"><span>01</span> / 01</span>
          </div>

          <form className="simplifier-form" onSubmit={handleSubmit}>
            <label className="field-label" htmlFor="topic">Your topic</label>
            <div className="topic-input-wrap">
              <Lightbulb className="input-icon" size={19} />
              <input
                ref={inputRef}
                id="topic"
                name="topic"
                type="text"
                value={topic}
                onChange={(event) => setTopic(event.target.value)}
                placeholder="Try quantum computing, neural networks, blockchain..."
                maxLength={180}
                required
                autoComplete="off"
              />
              {topic && <span className="character-count">{topic.length}/180</span>}
            </div>

            <fieldset className="age-fieldset">
              <legend className="field-label">Explain it for</legend>
              <div className="age-options">
                {ageGroups.map(({ id, label, detail, Icon }) => (
                  <label className={`age-option${ageGroup === id ? " selected" : ""}`} key={id}>
                    <input
                      type="radio"
                      name="age_group"
                      value={id}
                      checked={ageGroup === id}
                      onChange={() => setAgeGroup(id)}
                    />
                    <span className="age-option-icon"><Icon size={19} strokeWidth={1.8} /></span>
                    <span className="age-option-copy"><strong>{label}</strong><small>{detail}</small></span>
                    <span className="radio-indicator" aria-hidden="true" />
                  </label>
                ))}
              </div>
            </fieldset>

            <button className="submit-button" type="submit" disabled={!topic.trim() || loading}>
              {loading ? <><LoaderCircle className="button-spinner" size={18} /> Simplifying...</> : <><Sparkles size={17} /> Simplify this topic <ArrowRight size={17} /></>}
            </button>
            <p className="form-note"><span className="note-stars"><Sparkles size={13} /></span> Powered by AI <span className="note-divider">·</span> Tailored to your learning level</p>
          </form>

          <div className="examples-row">
            <span className="examples-label">Not sure where to start?</span>
            <div className="example-list" aria-label="Example topics">
              {examples.map((example) => (
                <button
                  className="example-chip"
                  key={example}
                  type="button"
                  onClick={() => {
                    setTopic(example);
                    setError("");
                    inputRef.current?.focus();
                  }}
                >
                  {example}<ArrowRight size={13} />
                </button>
              ))}
            </div>
          </div>

          <ExplanationPanel
            result={result}
            loading={loading}
            error={error}
            onCopy={handleCopy}
            copied={copied}
            onReset={resetResult}
          />
        </section>

        <section className="how-section page-width" id="how-it-works">
          <div className="how-heading">
            <span className="section-kicker">A clearer way to learn</span>
            <h2>Complex doesn’t have to mean confusing.</h2>
          </div>
          <div className="steps-grid">
            <article className="step-item">
              <span className="step-number">01</span>
              <h3>Choose a topic</h3>
              <p>Start with anything you’re curious about, from everyday tech to the edges of the universe.</p>
            </article>
            <article className="step-item">
              <span className="step-number">02</span>
              <h3>Pick your level</h3>
              <p>We adjust the language, detail, and examples to meet you where you are.</p>
            </article>
            <article className="step-item">
              <span className="step-number">03</span>
              <h3>Understand more</h3>
              <p>Get a thoughtful explanation with a useful analogy, ready to revisit or share.</p>
            </article>
          </div>
        </section>
      </main>

      <footer className="site-footer page-width" id="about">
        <a className="footer-brand" href="#home"><span className="footer-mark"><Lightbulb size={15} /></span> SimplifyAI</a>
        <p>Made for curious minds, at every age.</p>
        <a className="footer-top" href="#home">Back to top <ArrowRight size={14} /></a>
      </footer>
    </div>
  );
}

export default App;