import logging
import os

from fastapi import FastAPI
from fastapi import HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.prompts import create_prompt
from backend.llm import generate_explanation


logger = logging.getLogger(__name__)

app = FastAPI(
    title="Complex Topic Simplifier",
    description="An age-based technical concept explanation system",
    version="1.0.0"
)

if os.getenv("APP_ENV", "").strip().lower() == "development":
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://127.0.0.1:5173",
            "http://localhost:5173",
        ],
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )


class ExplanationRequest(BaseModel):
    topic: str
    age_group: str


@app.get("/")
def home():
    return {
        "message": "Complex Topic Simplifier API is running!"
    }



@app.post("/explain")
def explain(request: ExplanationRequest):

    prompt = create_prompt(
        request.topic,
        request.age_group
    )

    if prompt is None:
        raise HTTPException(
            status_code=422,
            detail="Invalid age group. Use child, teen, or adult.",
        )

    try:
        explanation = generate_explanation(prompt)
    except Exception as exc:
        status_code = getattr(exc, "status_code", None)
        logger.error(
            "Explanation generation failed (error_type=%s, upstream_status=%s)",
            type(exc).__name__,
            status_code,
        )
        raise HTTPException(
            status_code=502,
            detail="The AI service could not generate an explanation. Please try again shortly.",
        ) from None

    if not explanation:
        logger.error("Explanation generation returned an empty response")
        raise HTTPException(
            status_code=502,
            detail="The AI service returned an empty explanation. Please try again shortly.",
        )

    return {
        "topic": request.topic,
        "age_group": request.age_group,
        "explanation": explanation
    }
